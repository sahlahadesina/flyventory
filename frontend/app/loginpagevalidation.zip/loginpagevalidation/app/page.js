import Login from "./loginpage";

export default function Home() {
  return (
    <main>
      <Login />
    </main>
  );
}




